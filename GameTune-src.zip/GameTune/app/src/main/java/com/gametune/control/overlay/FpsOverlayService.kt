package com.gametune.control

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.gametune.control.core.GameEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale

class FpsOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var view: TextView? = null
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var job: Job? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startForegroundWithNotification()
        createOverlay()
        job = scope.launch { while (true) { updateText(); delay(1000) } }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() { job?.cancel(); scope.cancel(); view?.let { wm.removeView(it) }; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null

    private fun startForegroundWithNotification() {
        val ch = NotificationChannel("fps_overlay", "FPS监控", NotificationManager.IMPORTANCE_LOW)
        getSystemService(NOTIFICATION_SERVICE) as NotificationManager.createNotificationChannel(ch)
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        startForeground(1, NotificationCompat.Builder(this, "fps_overlay").setContentTitle("性能派运行中").setSmallIcon(R.drawable.ic_launcher).setContentIntent(pi).setOngoing(true).build())
    }

    private fun createOverlay() {
        val v = TextView(this).apply { setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 11f); setTextColor(Color.WHITE); setBackgroundColor(Color.argb(160, 0, 0, 0)); setPadding(20, 12, 20, 12); gravity = Gravity.START; text = "FPS --" }
        val p = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 16; y = 180 }
        var ix = 0, iy = 0; var itx = 0f; var ity = 0f
        v.setOnTouchListener { _, ev -> when (ev.action) { MotionEvent.ACTION_DOWN -> { ix = p.x; iy = p.y; itx = ev.rawX; ity = ev.rawY; true } MotionEvent.ACTION_MOVE -> { p.x = ix + (ev.rawX - itx).toInt(); p.y = iy + (ev.rawY - ity).toInt(); wm.updateViewLayout(v, p); true } else -> false } }
        wm.addView(v, p); view = v
    }

    private suspend fun updateText() {
        val fps = GameEngine.getCurrentFPS()
        val mode = GameEngine.currentMode()?.label ?: "--"
        view?.text = String.format(Locale.US, "FPS %d\n模式 %s", fps, mode)
    }

    companion object {
        fun start(ctx: Context) { ctx.startForegroundService(Intent(ctx, FpsOverlayService::class.java)) }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, FpsOverlayService::class.java)) }
    }
}
