package com.gametune.control.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.gametune.control.core.PowerMode
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel = viewModel()) {
    val scope = rememberCoroutineScope()
    val isRoot by viewModel.isRoot.collectAsState()
    val refreshOn by viewModel.refreshOn.collectAsState()
    val schedOn by viewModel.schedOn.collectAsState()
    val currentMode by viewModel.currentMode.collectAsState()

    LaunchedEffect(Unit) { viewModel.refresh() }

    Scaffold(topBar = {
        TopAppBar(title = { Text("性能派", fontWeight = FontWeight.Bold) }, colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primaryContainer, titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer))
    }) { padding ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(vertical = 12.dp)) {
            if (!isRoot) { item { Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFF5252))) { Text("未获取 Root 权限", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(12.dp)) } } }

            item {
                FeatureCard(Icons.Filled.Refresh, "刷新率管理", if (refreshOn) "已锁定 144Hz" else "当前 ${viewModel.currentHz.value}Hz", isRoot, refreshOn) { scope.launch { viewModel.setRefreshRate(!refreshOn) } }
            }
            item {
                FeatureCard(Icons.Filled.Speed, "调度接管", if (schedOn) "MIUI 降频服务已接管" else "系统默认调度", isRoot, schedOn) { scope.launch { if (schedOn) viewModel.disableSched() else viewModel.enableSched() } }
            }
            item {
                Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Uperf 模式", style = MaterialTheme.typography.titleSmall)
                        Text("当前：${currentMode?.label ?: "--"}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                            PowerMode.entries.forEach { mode ->
                                val selected = currentMode == mode
                                Button(onClick = { scope.launch { viewModel.setMode(mode) } }, enabled = isRoot, modifier = Modifier.weight(1f).height(36.dp), colors = ButtonDefaults.buttonColors(containerColor = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondaryContainer, contentColor = if (selected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSecondaryContainer) ) { Text(mode.label, style = MaterialTheme.typography.labelSmall) }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FeatureCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, enabled: Boolean, checked: Boolean, onToggle: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(enabled = enabled, onClick = onToggle), colors = CardDefaults.cardColors(containerColor = if (checked) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant)) {
        Row(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, contentDescription = title, tint = if (checked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                Column { Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold); Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
            Switch(checked = checked, enabled = enabled, onCheckedChange = { onToggle() })
        }
    }
}
